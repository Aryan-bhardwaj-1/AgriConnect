// FarmerDashboard.jsx

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./FarmerDashboard.css";

function FarmerDashboard() {
  const navigate = useNavigate();

  const farmer = JSON.parse(localStorage.getItem("farmer")) || {
    name: "Farmer",
    email: "farmer@example.com",
  };

  const [activeMenu, setActiveMenu] = useState("Dashboard");

  const menuItems = [
    ["🏠", "Dashboard"],
    ["🌾", "My Products"],
    ["➕", "Add Product"],
    ["📦", "Orders"],
    ["💰", "Earnings"],
    ["📈", "Analytics"],
    ["👤", "Profile"],
    ["⚙️", "Settings"],
  ];

  const products = [
    ["🍅", "Fresh Tomatoes", "Vegetable", "250 kg", "₹35/kg", "Available"],
    ["🥔", "Organic Potatoes", "Vegetable", "500 kg", "₹28/kg", "Available"],
    ["🌾", "Premium Wheat", "Grain", "800 kg", "₹32/kg", "Low Stock"],
    ["🧅", "Fresh Onions", "Vegetable", "150 kg", "₹30/kg", "Available"],
  ];

  const orders = [
    ["#KD-1025", "Rahul Traders", "Tomatoes", "100 kg", "₹3,500", "Delivered"],
    ["#KD-1026", "Fresh Mart", "Potatoes", "200 kg", "₹5,600", "Processing"],
    ["#KD-1027", "Green Basket", "Wheat", "300 kg", "₹9,600", "Pending"],
  ];

  const logout = () => {
    localStorage.removeItem("farmer");
    navigate("/farmer-login");
  };

  return (
    <div className="farmer-dashboard">

      <aside className="sidebar">

        <div className="brand">
          <div className="brand-icon">🌾</div>
          <div>
            <h2>Kisan Direct</h2>
            <span>Farmer Portal</span>
          </div>
        </div>

        <p className="menu-title">MAIN MENU</p>

        <nav>
          {menuItems.map(([icon, name]) => (
            <button
              key={name}
              className={activeMenu === name ? "menu active" : "menu"}
              onClick={() => setActiveMenu(name)}
            >
              <span>{icon}</span>
              {name}
            </button>
          ))}
        </nav>

        <div className="help-box">
          <span>💬</span>
          <h4>Need Help?</h4>
          <p>Our support team is always ready to help.</p>
          <button>Contact Support</button>
        </div>

        <button className="logout" onClick={logout}>
          🚪 Logout
        </button>

      </aside>


      <main className="main">

        <header className="topbar">

          <div className="mobile-brand">
            🌾 Kisan Direct
          </div>

          <div className="search">
            🔍
            <input placeholder="Search products, orders..." />
          </div>

          <div className="top-right">

            <button className="top-button">
              🔔
              <b>3</b>
            </button>

            <button className="top-button">
              💬
            </button>

            <div className="user">

              <div className="avatar">
                {farmer.name?.charAt(0).toUpperCase()}
              </div>

              <div>
                <strong>{farmer.name}</strong>
                <small>Farmer</small>
              </div>

              <span>⌄</span>

            </div>

          </div>

        </header>


        <section className="content">

          <div className="welcome">

            <div>
              <small>Sunday, September 6, 2026</small>

              <h1>
                Good Morning, {farmer.name?.split(" ")[0]}! 👋
              </h1>

              <p>
                Manage your farm, products, orders and earnings from one place.
              </p>
            </div>

            <button
              onClick={() => setActiveMenu("Add Product")}
            >
              ＋ Add New Product
            </button>

          </div>


          <div className="stats">

            <div className="stat">
              <div className="stat-icon green">🌾</div>
              <div>
                <span>Total Products</span>
                <h2>24</h2>
                <small>↑ 12.5% this month</small>
              </div>
            </div>

            <div className="stat">
              <div className="stat-icon blue">📦</div>
              <div>
                <span>Total Orders</span>
                <h2>156</h2>
                <small>↑ 8.2% this week</small>
              </div>
            </div>

            <div className="stat">
              <div className="stat-icon orange">💰</div>
              <div>
                <span>Total Revenue</span>
                <h2>₹48,560</h2>
                <small>↑ 15.8% this month</small>
              </div>
            </div>

            <div className="stat">
              <div className="stat-icon purple">⭐</div>
              <div>
                <span>Farmer Rating</span>
                <h2>4.8</h2>
                <small>From 86 buyers</small>
              </div>
            </div>

          </div>


          <div className="grid-two">

            <div className="card">

              <div className="card-head">
                <div>
                  <h3>Sales Overview</h3>
                  <p>Your revenue performance</p>
                </div>

                <select>
                  <option>Last 7 Days</option>
                  <option>Last 30 Days</option>
                  <option>Last 6 Months</option>
                </select>
              </div>

              <div className="chart">

                <div className="chart-y">
                  <span>₹20K</span>
                  <span>₹15K</span>
                  <span>₹10K</span>
                  <span>₹5K</span>
                  <span>₹0</span>
                </div>

                <div className="chart-body">

                  <div className="line l1"></div>
                  <div className="line l2"></div>
                  <div className="line l3"></div>
                  <div className="line l4"></div>
                  <div className="line l5"></div>

                  <svg
                    viewBox="0 0 700 240"
                    preserveAspectRatio="none"
                  >
                    <path
                      d="M0 190
                      C60 175 80 125 140 145
                      C200 165 220 95 280 115
                      C340 135 365 70 425 90
                      C480 110 510 120 560 70
                      C610 25 655 60 700 35"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="5"
                    />
                  </svg>

                  <div className="days">
                    <span>Mon</span>
                    <span>Tue</span>
                    <span>Wed</span>
                    <span>Thu</span>
                    <span>Fri</span>
                    <span>Sat</span>
                    <span>Sun</span>
                  </div>

                </div>

              </div>

            </div>


            <div className="card weather">

              <div className="card-head">
                <div>
                  <h3>Today's Weather</h3>
                  <p>Your farm location</p>
                </div>

                <span className="sun">☀️</span>
              </div>

              <h1>29°<small>C</small></h1>

              <p className="sunny">Sunny & Clear</p>

              <div className="weather-data">

                <div>
                  💧
                  <strong>65%</strong>
                  <small>Humidity</small>
                </div>

                <div>
                  💨
                  <strong>12 km/h</strong>
                  <small>Wind</small>
                </div>

                <div>
                  🌧️
                  <strong>10%</strong>
                  <small>Rain</small>
                </div>

              </div>

              <div className="weather-tip">
                🌱 Good conditions for farming today.
              </div>

            </div>

          </div>


          <div className="grid-two">

            <div className="card">

              <div className="card-head">

                <div>
                  <h3>Recent Orders</h3>
                  <p>Latest buyer orders</p>
                </div>

                <button
                  className="view"
                  onClick={() => setActiveMenu("Orders")}
                >
                  View All →
                </button>

              </div>

              <div className="orders">

                {orders.map((order) => (
                  <div className="order" key={order[0]}>

                    <div className="order-icon">
                      📦
                    </div>

                    <div className="order-info">
                      <strong>{order[2]}</strong>
                      <small>
                        {order[0]} • {order[1]}
                      </small>
                    </div>

                    <span>{order[3]}</span>

                    <strong>{order[4]}</strong>

                    <label className={order[5].toLowerCase()}>
                      {order[5]}
                    </label>

                  </div>
                ))}

              </div>

            </div>


            <div className="card">

              <div className="card-head">

                <div>
                  <h3>Market Prices</h3>
                  <p>Today's average rates</p>
                </div>

                <b className="live">● LIVE</b>

              </div>

              <div className="market">

                <div>
                  <span>🍅 Tomato</span>
                  <strong>₹35/kg</strong>
                  <em>↑ 5.2%</em>
                </div>

                <div>
                  <span>🥔 Potato</span>
                  <strong>₹28/kg</strong>
                  <em>↑ 2.8%</em>
                </div>

                <div>
                  <span>🌾 Wheat</span>
                  <strong>₹32/kg</strong>
                  <em>↑ 4.1%</em>
                </div>

                <div>
                  <span>🧅 Onion</span>
                  <strong>₹30/kg</strong>
                  <em>↓ 1.5%</em>
                </div>

              </div>

              <button className="market-btn">
                View Market Trends →
              </button>

            </div>

          </div>


          <div className="card products">

            <div className="card-head">

              <div>
                <h3>My Products</h3>
                <p>Manage your listed crops</p>
              </div>

              <button
                className="view"
                onClick={() => setActiveMenu("My Products")}
              >
                View All →
              </button>

            </div>

            <div className="product-table">

              <div className="product-head">
                <span>Product</span>
                <span>Category</span>
                <span>Quantity</span>
                <span>Price</span>
                <span>Status</span>
                <span>Action</span>
              </div>

              {products.map((product) => (

                <div className="product-row" key={product[1]}>

                  <div className="product-name">
                    <span>{product[0]}</span>
                    <strong>{product[1]}</strong>
                  </div>

                  <span>{product[2]}</span>
                  <span>{product[3]}</span>
                  <strong>{product[4]}</strong>

                  <label
                    className={
                      product[5] === "Available"
                        ? "available"
                        : "low"
                    }
                  >
                    ● {product[5]}
                  </label>

                  <button className="edit">
                    Edit
                  </button>

                </div>

              ))}

            </div>

          </div>


          <div className="quick">

            <div>
              <h3>Quick Actions</h3>
              <p>Manage your farming business</p>
            </div>

            <div className="quick-grid">

              <button onClick={() => setActiveMenu("Add Product")}>
                <span>➕</span>
                <strong>Add Product</strong>
                <small>List a new crop</small>
              </button>

              <button onClick={() => setActiveMenu("Orders")}>
                <span>📦</span>
                <strong>Manage Orders</strong>
                <small>Track your orders</small>
              </button>

              <button onClick={() => setActiveMenu("Earnings")}>
                <span>💰</span>
                <strong>View Earnings</strong>
                <small>Check your income</small>
              </button>

              <button onClick={() => setActiveMenu("Analytics")}>
                <span>📊</span>
                <strong>Analytics</strong>
                <small>View business insights</small>
              </button>

            </div>

          </div>


          <div className="ai-card">

            <div className="ai-icon">
              🤖
            </div>

            <div>
              <small>AI FARM ASSISTANT</small>

              <h3>
                Today's Recommendation
              </h3>

              <p>
                Tomato demand is expected to increase this week.
                Consider listing more tomatoes while the market
                price is favorable.
              </p>
            </div>

            <button>
              View Insights →
            </button>

          </div>

        </section>

      </main>

    </div>
  );
}

export default FarmerDashboard;