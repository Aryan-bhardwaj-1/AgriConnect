import React from "react";
import "./Home.css";

const products = [
  {
    name: "Fresh Tomatoes",
    farmer: "Ramesh Kumar",
    price: "₹35/kg",
    image: "/images/vegetables.jpg",
  },
  {
    name: "Organic Potatoes",
    farmer: "Suresh Yadav",
    price: "₹28/kg",
    image: "/images/marketplace.jpg",
  },
  {
    name: "Fresh Wheat",
    farmer: "Amit Singh",
    price: "₹42/kg",
    image: "/images/farmer.jpg",
  },
];

function Home() {
  return (
    <div className="home">

      {/* NAVBAR */}
      <nav className="navbar">
        <div className="logo">
          🌾 Kisan<span>Direct</span>
        </div>

        <div className="nav-links">
          <a href="/">Home</a>
          <a href="/products">Products</a>
          <a href="/farmers">Farmers</a>
          <a href="/about">About</a>
          <a href="/contact">Contact</a>
        </div>

        <div className="nav-buttons">
          <button className="login-btn">Login</button>
          <button className="signup-btn">Get Started</button>
        </div>
      </nav>


      {/* HERO */}
      <section className="hero">

        <div className="hero-content">

          <div className="badge">
            🌱 Empowering Indian Farmers
          </div>

          <h1>
            From <span>Farm</span>
            <br />
            Directly to You
          </h1>

          <p>
            Buy fresh agricultural products directly from farmers.
            Better prices for farmers, fresher products for consumers.
          </p>

          <div className="hero-buttons">
            <button className="primary-btn">
              Explore Products →
            </button>

            <button className="secondary-btn">
              👨‍🌾 Join as Farmer
            </button>
          </div>

          <div className="trust">
            ⭐ 4.9/5 &nbsp;&nbsp; | &nbsp;&nbsp;
            10,000+ Farmers &nbsp;&nbsp; | &nbsp;&nbsp;
            50,000+ Buyers
          </div>

        </div>

        <div className="hero-image">
          <img
            src="/images/farmer.jpg"
            alt="Indian farmer"
          />

          <div className="floating-card">
            <div className="check">✓</div>
            <div>
              <strong>Direct Trade</strong>
              <p>No middlemen</p>
            </div>
          </div>

        </div>

      </section>


      {/* STATS */}
      <section className="stats">

        <div>
          <h2>10K+</h2>
          <p>Farmers Connected</p>
        </div>

        <div>
          <h2>50K+</h2>
          <p>Happy Customers</p>
        </div>

        <div>
          <h2>25K+</h2>
          <p>Orders Delivered</p>
        </div>

        <div>
          <h2>₹2Cr+</h2>
          <p>Farmer Revenue</p>
        </div>

      </section>


      {/* CATEGORIES */}
      <section className="section">

        <div className="section-title">
          <span>EXPLORE</span>
          <h2>Fresh From The Farm</h2>
          <p>
            Discover quality agricultural products directly from verified farmers.
          </p>
        </div>

        <div className="categories">

          <div className="category-card">
            <div className="category-icon">🥬</div>
            <h3>Vegetables</h3>
            <p>Fresh & organic</p>
          </div>

          <div className="category-card">
            <div className="category-icon">🌾</div>
            <h3>Grains</h3>
            <p>Farm fresh grains</p>
          </div>

          <div className="category-card">
            <div className="category-icon">🍎</div>
            <h3>Fruits</h3>
            <p>Fresh seasonal fruits</p>
          </div>

          <div className="category-card">
            <div className="category-icon">🥛</div>
            <h3>Dairy</h3>
            <p>Pure dairy products</p>
          </div>

        </div>

      </section>


      {/* PRODUCTS */}
      <section className="products-section">

        <div className="section-title">
          <span>POPULAR PRODUCTS</span>
          <h2>Fresh Products Near You</h2>
        </div>

        <div className="products">

          {products.map((product, index) => (

            <div className="product-card" key={index}>

              <div className="product-image">
                <img src={product.image} alt={product.name} />

                <span className="organic">
                  ✓ Verified
                </span>
              </div>

              <div className="product-info">

                <h3>{product.name}</h3>

                <p className="farmer">
                  👨‍🌾 {product.farmer}
                </p>

                <div className="product-bottom">
                  <strong>{product.price}</strong>
                  <button>Add +</button>
                </div>

              </div>

            </div>

          ))}

        </div>

      </section>


      {/* HOW IT WORKS */}
      <section className="how-section">

        <div className="section-title">
          <span>SIMPLE PROCESS</span>
          <h2>How KisanDirect Works</h2>
        </div>

        <div className="steps">

          <div className="step">
            <div>01</div>
            <h3>Farmers List Products</h3>
            <p>
              Farmers upload their products, quantity and expected price.
            </p>
          </div>

          <div className="step">
            <div>02</div>
            <h3>Buyers Place Orders</h3>
            <p>
              Consumers and bulk buyers directly purchase products.
            </p>
          </div>

          <div className="step">
            <div>03</div>
            <h3>Smart Logistics</h3>
            <p>
              Our system optimizes routes for faster and cheaper delivery.
            </p>
          </div>

          <div className="step">
            <div>04</div>
            <h3>Direct Payment</h3>
            <p>
              Farmers receive better prices without unnecessary middlemen.
            </p>
          </div>

        </div>

      </section>


      {/* FARMER SECTION */}
      <section className="farmer-section">

        <div className="farmer-image">
          <img
            src="/images/marketplace.jpg"
            alt="Farmers marketplace"
          />
        </div>

        <div className="farmer-content">

          <span>FOR FARMERS</span>

          <h2>
            Sell More.
            <br />
            Earn Better.
          </h2>

          <p>
            Connect directly with consumers and bulk buyers.
            Get transparent pricing and expand your market without
            depending completely on traditional middlemen.
          </p>

          <div className="benefits">

            <div>✓ Direct access to buyers</div>
            <div>✓ Better product prices</div>
            <div>✓ Transparent transactions</div>
            <div>✓ Logistics support</div>
            <div>✓ Digital marketplace</div>
            <div>✓ Demand insights</div>

          </div>

          <button className="primary-btn">
            Start Selling →
          </button>

        </div>

      </section>


      {/* AI SECTION */}
      <section className="ai-section">

        <div className="ai-content">

          <span>SMART AGRICULTURE</span>

          <h2>
            Powered by
            <br />
            Intelligent Technology
          </h2>

          <p>
            KisanDirect uses intelligent demand forecasting and
            route optimization to reduce wastage and improve
            agricultural supply chains.
          </p>

          <div className="ai-features">

            <div>
              🤖
              <strong>Demand Forecasting</strong>
            </div>

            <div>
              🚚
              <strong>Route Optimization</strong>
            </div>

            <div>
              📊
              <strong>Market Analytics</strong>
            </div>

          </div>

        </div>

      </section>


      {/* CTA */}
      <section className="cta">

        <h2>
          Let's Build a Better
          <br />
          Agricultural Future 🌱
        </h2>

        <p>
          Join thousands of farmers and buyers building a
          transparent agricultural marketplace.
        </p>

        <button className="primary-btn">
          Get Started Today →
        </button>

      </section>


      {/* FOOTER */}
      <footer>

        <div className="footer-logo">
          🌾 KisanDirect
        </div>

        <p>
          Connecting farmers directly with consumers.
        </p>

        <div className="footer-links">
          <a href="/">Home</a>
          <a href="/products">Products</a>
          <a href="/farmers">Farmers</a>
          <a href="/about">About</a>
          <a href="/contact">Contact</a>
        </div>

        <div className="copyright">
          © 2026 KisanDirect. All rights reserved.
        </div>

      </footer>

    </div>
  );
}

export default Home;