import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function FarmerLogin() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://127.0.0.1:5000/api/farmer/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        localStorage.setItem("farmer", JSON.stringify(data.farmer));

        alert("Login successful!");
        navigate("/farmer-dashboard");
      } else {
        alert(data.message || "Invalid email or password");
      }
    } catch (error) {
      alert("Server error. Please try again.");
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <h1>🌾 Kisan Direct</h1>
        <h2>Farmer Login</h2>
        <p>Login to manage your farm products</p>

        <form onSubmit={handleSubmit}>
          <input
            type="email"
            name="email"
            placeholder="Email Address"
            value={formData.email}
            onChange={handleChange}
            required
          />

          <input
            type="password"
            name="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            required
          />

          <button type="submit">
            Login
          </button>
        </form>

        <p>
          Don't have an account?{" "}
          <Link to="/farmer-signup">Create Account</Link>
        </p>
      </div>
    </div>
  );
}

export default FarmerLogin;