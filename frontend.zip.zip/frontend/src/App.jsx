import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import FarmerLogin from "./pages/FarmerLogin";
import FarmerSignup from "./pages/FarmerSignup";

function Home() {
  return (
    <div style={{ fontFamily: "Arial, sans-serif" }}>

      {/* Navbar */}
      <nav
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "18px 50px",
          backgroundColor: "#166534",
          color: "white",
        }}
      >
        <h2>🌾 AgriConnect</h2>

        <div>
          <Link to="/" style={linkStyle}>Home</Link>
          <Link to="/farmer-login" style={linkStyle}>Farmer Login</Link>
          <Link to="/farmer-signup" style={linkStyle}>Farmer Signup</Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section
        style={{
          minHeight: "500px",
          padding: "80px 10%",
          backgroundColor: "#f0fdf4",
          display: "flex",
          alignItems: "center",
        }}
      >
        <div>
          <h1
            style={{
              fontSize: "52px",
              color: "#166534",
              marginBottom: "15px",
            }}
          >
            Connecting Farmers
            <br />
            to a Better Connect 🌱
          </h1>

          <p
            style={{
              fontSize: "20px",
              color: "#4b5563",
              maxWidth: "600px",
              lineHeight: "1.6",
            }}
          >
            AgriConnect helps farmers connect with markets,
            buyers and agricultural services easily and directly.
          </p>

          <div style={{ marginTop: "30px" }}>
            <Link to="/farmer-login">
              <button style={buttonStyle}>
                Farmer Login
              </button>
            </Link>

            <Link to="/farmer-signup">
              <button
                style={{
                  ...buttonStyle,
                  backgroundColor: "white",
                  color: "#166534",
                  border: "2px solid #166534",
                  marginLeft: "15px",
                }}
              >
                Create Account
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section style={{ padding: "60px 8%" }}>
        <h2 style={{ textAlign: "center", color: "#166534" }}>
          Why AgriConnect?
        </h2>

        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "25px",
            marginTop: "35px",
            flexWrap: "wrap",
          }}
        >
          <Feature icon="🛒" title="Direct Market" />
          <Feature icon="🌱" title="Better Farming" />
          <Feature icon="💰" title="Fair Prices" />
          <Feature icon="🤝" title="Connect with Buyers" />
        </div>
      </section>

      {/* Footer */}
      <footer
        style={{
          backgroundColor: "#14532d",
          color: "white",
          textAlign: "center",
          padding: "25px",
        }}
      >
        <p>🌾 AgriConnect</p>
        <p>Connecting Farmers to a Better Connect</p>
      </footer>

    </div>
  );
}

function Feature({ icon, title }) {
  return (
    <div
      style={{
        width: "220px",
        padding: "30px 20px",
        textAlign: "center",
        borderRadius: "15px",
        backgroundColor: "#f0fdf4",
        boxShadow: "0 4px 15px rgba(0,0,0,0.08)",
      }}
    >
      <div style={{ fontSize: "40px" }}>{icon}</div>

      <h3 style={{ color: "#166534" }}>
        {title}
      </h3>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>

        <Route path="/" element={<Home />} />

        <Route
          path="/farmer-login"
          element={<FarmerLogin />}
        />

        <Route
          path="/farmer-signup"
          element={<FarmerSignup />}
        />

      </Routes>
    </BrowserRouter>
  );
}

const linkStyle = {
  color: "white",
  textDecoration: "none",
  marginLeft: "25px",
  fontSize: "16px",
};

const buttonStyle = {
  padding: "14px 25px",
  border: "none",
  borderRadius: "8px",
  backgroundColor: "#166534",
  color: "white",
  fontSize: "16px",
  cursor: "pointer",
};

export default App;